<?php
/**
 * FlexPBX Update Manager
 *
 * Handles automatic updates from main FlexPBX server:
 * - Version checking
 * - Update downloading
 * - Backup before update
 * - Rollback capability
 * - Multi-client update distribution
 *
 * @version 1.0
 * @package FlexPBX
 */

class UpdateManager {
    private $config;
    private $mainServerUrl;
    private $apiKey;
    private $currentVersion = '1.0';
    private $updatePath;
    private $backupPath;
    private $lastError = null;

    public function __construct($config = []) {
        $this->config = $config;
        $this->mainServerUrl = rtrim($config['main_server']['url'] ?? '', '/');
        $this->apiKey = $config['main_server']['api_key'] ?? '';
        $this->updatePath = __DIR__ . '/updates';
        $this->backupPath = __DIR__ . '/backups';

        // Create directories if they don't exist
        @mkdir($this->updatePath, 0755, true);
        @mkdir($this->backupPath, 0755, true);
    }

    /**
     * Check if update system is enabled
     */
    public function isEnabled() {
        return !empty($this->config['main_server']['enabled'])
            && !empty($this->mainServerUrl);
    }

    /**
     * Register this installation with main server
     */
    public function registerWithMainServer($installationData) {
        if (!$this->isEnabled()) {
            return ['success' => false, 'error' => 'Update system not enabled'];
        }

        $endpoint = $this->config['main_server']['registration_url'] ?? '/api/clients/register';

        $payload = [
            'version' => $this->currentVersion,
            'server_url' => $_SERVER['HTTP_HOST'] ?? 'unknown',
            'admin_email' => $installationData['admin_email'] ?? '',
            'installation_date' => date('Y-m-d H:i:s'),
            'php_version' => PHP_VERSION,
            'features' => $installationData['features'] ?? [],
        ];

        $response = $this->makeRequest('POST', $endpoint, $payload);

        if ($response['success']) {
            // Store client ID for future requests
            $this->storeClientId($response['data']['client_id'] ?? null);
        }

        return $response;
    }

    /**
     * Check for available updates
     */
    public function checkForUpdates() {
        if (!$this->isEnabled()) {
            return ['success' => false, 'error' => 'Update system not enabled'];
        }

        $endpoint = $this->config['main_server']['update_check_url'] ?? '/api/updates/check';

        $payload = [
            'client_id' => $this->getClientId(),
            'current_version' => $this->currentVersion,
            'update_channel' => $this->config['updates']['update_channel'] ?? 'stable',
        ];

        $response = $this->makeRequest('POST', $endpoint, $payload);

        if ($response['success'] && !empty($response['data']['update_available'])) {
            return [
                'success' => true,
                'update_available' => true,
                'latest_version' => $response['data']['version'] ?? 'unknown',
                'changelog' => $response['data']['changelog'] ?? '',
                'download_url' => $response['data']['download_url'] ?? '',
                'file_size' => $response['data']['file_size'] ?? 0,
                'release_date' => $response['data']['release_date'] ?? '',
            ];
        }

        return [
            'success' => true,
            'update_available' => false,
            'message' => 'You are running the latest version',
        ];
    }

    /**
     * Download update from main server
     */
    public function downloadUpdate($updateInfo) {
        if (!$this->isEnabled()) {
            return ['success' => false, 'error' => 'Update system not enabled'];
        }

        $downloadUrl = $updateInfo['download_url'] ?? '';
        if (empty($downloadUrl)) {
            return ['success' => false, 'error' => 'No download URL provided'];
        }

        // Full URL or relative path
        if (!preg_match('/^https?:\/\//', $downloadUrl)) {
            $downloadUrl = $this->mainServerUrl . $downloadUrl;
        }

        $filename = $this->updatePath . '/flexpbx_' . ($updateInfo['version'] ?? time()) . '.tar.gz';

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $downloadUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 300, // 5 minutes
            CURLOPT_SSL_VERIFYPEER => $this->config['main_server']['verify_ssl'] ?? true,
        ]);

        if (!empty($this->apiKey)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $this->apiKey,
            ]);
        }

        $updateData = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200 || $updateData === false) {
            return [
                'success' => false,
                'error' => 'Failed to download update (HTTP ' . $httpCode . ')',
            ];
        }

        file_put_contents($filename, $updateData);

        return [
            'success' => true,
            'filename' => $filename,
            'size' => filesize($filename),
        ];
    }

    /**
     * Create backup before update
     */
    public function createBackup() {
        $timestamp = date('Y-m-d_H-i-s');
        $backupFile = $this->backupPath . '/backup_' . $timestamp . '.tar.gz';

        $filesToBackup = [
            __DIR__ . '/../public_html',
            __DIR__ . '/../config',
            __DIR__ . '/../database',
        ];

        $command = 'tar -czf ' . escapeshellarg($backupFile);
        foreach ($filesToBackup as $file) {
            if (file_exists($file)) {
                $command .= ' ' . escapeshellarg($file);
            }
        }

        exec($command . ' 2>&1', $output, $returnCode);

        if ($returnCode === 0 && file_exists($backupFile)) {
            return [
                'success' => true,
                'backup_file' => $backupFile,
                'size' => filesize($backupFile),
            ];
        }

        return [
            'success' => false,
            'error' => 'Backup creation failed',
            'output' => implode("\n", $output),
        ];
    }

    /**
     * Install update
     */
    public function installUpdate($updateFile) {
        // Verify file exists
        if (!file_exists($updateFile)) {
            return ['success' => false, 'error' => 'Update file not found'];
        }

        // Create backup if enabled
        if (!empty($this->config['updates']['backup_before_update'])) {
            $backup = $this->createBackup();
            if (!$backup['success']) {
                return [
                    'success' => false,
                    'error' => 'Failed to create backup before update',
                ];
            }
        }

        // Extract update
        $extractPath = __DIR__ . '/../';
        $command = 'tar -xzf ' . escapeshellarg($updateFile) . ' -C ' . escapeshellarg($extractPath) . ' 2>&1';
        exec($command, $output, $returnCode);

        if ($returnCode !== 0) {
            return [
                'success' => false,
                'error' => 'Failed to extract update',
                'output' => implode("\n", $output),
            ];
        }

        // Run post-update script if it exists
        $postUpdateScript = $extractPath . '/post_update.php';
        if (file_exists($postUpdateScript)) {
            include $postUpdateScript;
        }

        return [
            'success' => true,
            'message' => 'Update installed successfully',
        ];
    }

    /**
     * Rollback to previous version
     */
    public function rollback($backupFile = null) {
        if (empty($backupFile)) {
            // Find most recent backup
            $backups = glob($this->backupPath . '/backup_*.tar.gz');
            if (empty($backups)) {
                return ['success' => false, 'error' => 'No backups found'];
            }
            rsort($backups);
            $backupFile = $backups[0];
        }

        if (!file_exists($backupFile)) {
            return ['success' => false, 'error' => 'Backup file not found'];
        }

        $extractPath = __DIR__ . '/../';
        $command = 'tar -xzf ' . escapeshellarg($backupFile) . ' -C ' . escapeshellarg($extractPath) . ' 2>&1';
        exec($command, $output, $returnCode);

        if ($returnCode === 0) {
            return [
                'success' => true,
                'message' => 'Rollback completed successfully',
            ];
        }

        return [
            'success' => false,
            'error' => 'Rollback failed',
            'output' => implode("\n", $output),
        ];
    }

    /**
     * Get list of available backups
     */
    public function listBackups() {
        $backups = glob($this->backupPath . '/backup_*.tar.gz');
        $result = [];

        foreach ($backups as $backup) {
            $result[] = [
                'filename' => basename($backup),
                'path' => $backup,
                'size' => filesize($backup),
                'date' => date('Y-m-d H:i:s', filemtime($backup)),
            ];
        }

        // Sort by date descending
        usort($result, function($a, $b) {
            return strcmp($b['date'], $a['date']);
        });

        return $result;
    }

    /**
     * Make HTTP request to main server
     */
    private function makeRequest($method, $endpoint, $data = []) {
        $url = $this->mainServerUrl . $endpoint;

        $ch = curl_init();
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: FlexPBX-Client/1.0',
        ];

        if (!empty($this->apiKey)) {
            $headers[] = 'Authorization: Bearer ' . $this->apiKey;
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => $this->config['main_server']['timeout'] ?? 30,
            CURLOPT_SSL_VERIFYPEER => $this->config['main_server']['verify_ssl'] ?? true,
        ]);

        if ($method === 'POST' || $method === 'PUT') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false) {
            return [
                'success' => false,
                'error' => 'Request failed',
                'http_code' => $httpCode,
            ];
        }

        $decoded = json_decode($response, true);

        return [
            'success' => $httpCode >= 200 && $httpCode < 300,
            'http_code' => $httpCode,
            'data' => $decoded ?? [],
        ];
    }

    /**
     * Store client ID
     */
    private function storeClientId($id) {
        if (empty($id)) return;

        $configFile = __DIR__ . '/client_registration.json';
        $config = [
            'client_id' => $id,
            'registered_at' => date('Y-m-d H:i:s'),
        ];
        file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
    }

    /**
     * Get stored client ID
     */
    private function getClientId() {
        $configFile = __DIR__ . '/client_registration.json';
        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true);
            return $config['client_id'] ?? null;
        }
        return null;
    }

    /**
     * Get last error
     */
    public function getLastError() {
        return $this->lastError;
    }
}
