<?php
/**
 * FlexPBX Client Installer
 *
 * Lightweight installer for client servers that connects to master FlexPBX server
 * for updates, configuration, and management.
 *
 * Features:
 * - Detects installed services (WHM/cPanel, WHMCS, WordPress, Composr)
 * - Only installs hooks for detected services
 * - Connects to master FlexPBX API
 * - HubNode API fallback
 * - Auto-configures based on server environment
 *
 * Master Server: flexpbx.devinecreations.net
 * HubNode Fallback: (configure after setup)
 *
 * @version 1.0
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

// Master server configuration
define('MASTER_SERVER_URL', 'https://flexpbx.devinecreations.net');
define('MASTER_API_ENDPOINT', '/api');
define('HUBNODE_URL', ''); // Configure as fallback

class FlexPBXClientInstaller {
    private $step;
    private $errors = [];
    private $warnings = [];
    private $success = [];
    private $detectedServices = [];
    private $masterServerUrl;
    private $apiKey = null;

    public function __construct() {
        $this->step = $_GET['step'] ?? 'welcome';
        $this->masterServerUrl = MASTER_SERVER_URL;
    }

    public function run() {
        switch ($this->step) {
            case 'welcome':
                $this->showWelcome();
                break;
            case 'detect':
                $this->detectServices();
                break;
            case 'configure':
                $this->configureConnection();
                break;
            case 'install':
                $this->performInstallation();
                break;
            case 'complete':
                $this->showComplete();
                break;
            default:
                $this->showWelcome();
        }
    }

    private function showWelcome() {
        $this->renderHeader('FlexPBX Client Installer');
        ?>
        <div class="welcome-section">
            <h2>FlexPBX Client Installation</h2>
            <p>This installer will connect your server to the <strong>FlexPBX Master Server</strong> for centralized management and updates.</p>

            <div class="info-box">
                <h3>What this installer does:</h3>
                <ul>
                    <li>✅ Detects installed services (cPanel, WHMCS, WordPress, etc.)</li>
                    <li>✅ Installs only needed integration hooks</li>
                    <li>✅ Connects to master server API for updates</li>
                    <li>✅ Configures automatic synchronization</li>
                    <li>✅ Sets up HubNode fallback (optional)</li>
                </ul>
            </div>

            <div class="server-info">
                <h3>Master Server</h3>
                <p><strong>URL:</strong> <?php echo htmlspecialchars($this->masterServerUrl); ?></p>
                <p><strong>API:</strong> <?php echo htmlspecialchars($this->masterServerUrl . MASTER_API_ENDPOINT); ?></p>
            </div>

            <div class="action-buttons">
                <a href="?step=detect" class="btn btn-primary">Begin Installation →</a>
            </div>
        </div>
        <?php
        $this->renderFooter();
    }

    private function detectServices() {
        $this->renderHeader('Detecting Services');

        echo '<div class="detect-section">';
        echo '<h2>🔍 Detecting Installed Services...</h2>';
        echo '<div class="progress-container">';

        // Detect distribution
        $this->logProgress("Detecting Linux distribution...");
        require_once __DIR__ . '/includes/DistroDetector.php';
        $distro = new DistroDetector();
        $this->detectedServices['distro'] = [
            'name' => $distro->getPrettyName(),
            'id' => $distro->getId(),
            'version' => $distro->getVersion(),
            'package_manager' => $distro->getPackageManager(),
        ];
        $this->logProgress("✅ Detected: " . $distro->getPrettyName());

        // Detect cPanel/WHM
        $this->logProgress("Checking for cPanel/WHM...");
        if (file_exists('/usr/local/cpanel/version')) {
            $cpanelVersion = trim(file_get_contents('/usr/local/cpanel/version'));
            $this->detectedServices['cpanel'] = [
                'installed' => true,
                'version' => $cpanelVersion,
                'path' => '/usr/local/cpanel',
            ];
            $this->logProgress("✅ Found cPanel/WHM version {$cpanelVersion}");
        } else {
            $this->logProgress("⚪ cPanel/WHM not detected");
        }

        // Detect WHMCS
        $this->logProgress("Checking for WHMCS...");
        $whmcsPaths = [
            '/usr/local/cpanel/whostmgr/docroot/cgi/whmcs',
            '/home/*/public_html/whmcs',
            '/var/www/html/whmcs',
        ];
        foreach ($whmcsPaths as $pattern) {
            $found = glob($pattern, GLOB_ONLYDIR);
            if (!empty($found)) {
                $whmcsPath = $found[0];
                if (file_exists($whmcsPath . '/configuration.php')) {
                    $this->detectedServices['whmcs'] = [
                        'installed' => true,
                        'path' => $whmcsPath,
                    ];
                    $this->logProgress("✅ Found WHMCS at {$whmcsPath}");
                    break;
                }
            }
        }
        if (!isset($this->detectedServices['whmcs'])) {
            $this->logProgress("⚪ WHMCS not detected");
        }

        // Detect WordPress
        $this->logProgress("Checking for WordPress...");
        $wpPaths = [
            '/home/*/public_html/wp-config.php',
            '/var/www/html/wp-config.php',
        ];
        $wpInstalls = [];
        foreach ($wpPaths as $pattern) {
            $found = glob($pattern);
            foreach ($found as $wpConfig) {
                $wpInstalls[] = dirname($wpConfig);
            }
        }
        if (!empty($wpInstalls)) {
            $this->detectedServices['wordpress'] = [
                'installed' => true,
                'count' => count($wpInstalls),
                'paths' => $wpInstalls,
            ];
            $this->logProgress("✅ Found " . count($wpInstalls) . " WordPress installation(s)");
        } else {
            $this->logProgress("⚪ WordPress not detected");
        }

        // Detect Composr
        $this->logProgress("Checking for Composr CMS...");
        $composrPaths = [
            '/home/*/public_html/info.php',
            '/var/www/html/info.php',
        ];
        foreach ($composrPaths as $pattern) {
            $found = glob($pattern);
            foreach ($found as $infoFile) {
                $content = file_get_contents($infoFile);
                if (strpos($content, 'Composr') !== false) {
                    $this->detectedServices['composr'] = [
                        'installed' => true,
                        'path' => dirname($infoFile),
                    ];
                    $this->logProgress("✅ Found Composr at " . dirname($infoFile));
                    break 2;
                }
            }
        }
        if (!isset($this->detectedServices['composr'])) {
            $this->logProgress("⚪ Composr not detected");
        }

        // Detect Apache/Nginx
        $this->logProgress("Checking web server...");
        if (file_exists('/etc/httpd/conf/httpd.conf') || file_exists('/etc/apache2/apache2.conf')) {
            $this->detectedServices['webserver'] = 'apache';
            $this->logProgress("✅ Apache detected");
        } elseif (file_exists('/etc/nginx/nginx.conf')) {
            $this->detectedServices['webserver'] = 'nginx';
            $this->logProgress("✅ Nginx detected");
        }

        // Detect Asterisk
        $this->logProgress("Checking for Asterisk...");
        $asteriskVersion = shell_exec('asterisk -V 2>/dev/null');
        if (!empty($asteriskVersion)) {
            $this->detectedServices['asterisk'] = [
                'installed' => true,
                'version' => trim($asteriskVersion),
            ];
            $this->logProgress("✅ " . trim($asteriskVersion));
        } else {
            $this->logProgress("⚠️  Asterisk not detected - will need to install");
        }

        // Store detected services in session
        $_SESSION['detected_services'] = $this->detectedServices;

        echo '</div>';

        // Show summary
        echo '<div class="detection-summary">';
        echo '<h3>Detection Summary</h3>';
        echo '<table>';
        echo '<tr><th>Service</th><th>Status</th><th>Details</th></tr>';

        foreach ($this->detectedServices as $service => $info) {
            $status = isset($info['installed']) && $info['installed'] ? '✅ Installed' : 'ℹ️ Detected';
            $details = '';

            if ($service === 'distro') {
                $details = $info['name'];
            } elseif (isset($info['version'])) {
                $details = is_array($info['version']) ? implode(', ', $info['version']) : $info['version'];
            } elseif (isset($info['count'])) {
                $details = $info['count'] . ' installation(s)';
            } elseif (isset($info['path'])) {
                $details = basename($info['path']);
            }

            echo "<tr><td>" . ucfirst($service) . "</td><td>{$status}</td><td>{$details}</td></tr>";
        }

        echo '</table>';
        echo '</div>';

        echo '<div class="action-buttons">';
        echo '<a href="?step=configure" class="btn btn-primary">Continue to Configuration →</a>';
        echo '</div>';

        echo '</div>';
        $this->renderFooter();
    }

    private function configureConnection() {
        $this->renderHeader('Configure Master Server Connection');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Process form submission
            $apiKey = $_POST['api_key'] ?? '';
            $testConnection = $this->testMasterServerConnection($apiKey);

            if ($testConnection['success']) {
                $_SESSION['api_key'] = $apiKey;
                $_SESSION['master_server_url'] = $this->masterServerUrl;
                header('Location: ?step=install');
                exit;
            } else {
                $this->errors[] = "Connection failed: " . ($testConnection['error'] ?? 'Unknown error');
            }
        }

        ?>
        <div class="configure-section">
            <h2>Master Server Connection</h2>

            <?php if (!empty($this->errors)): ?>
                <div class="alert alert-error">
                    <?php foreach ($this->errors as $error): ?>
                        <p>❌ <?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Master Server URL</label>
                    <input type="text" name="master_url" value="<?php echo htmlspecialchars($this->masterServerUrl); ?>" readonly class="readonly">
                    <small>This is your FlexPBX master server</small>
                </div>

                <div class="form-group">
                    <label>API Key <span class="required">*</span></label>
                    <input type="text" name="api_key" placeholder="Enter your 64-character API key" required>
                    <small>You can generate an API key in the master server admin panel</small>
                </div>

                <div class="form-group">
                    <label>HubNode URL (Optional)</label>
                    <input type="text" name="hubnode_url" placeholder="https://hubnode.example.com">
                    <small>Fallback server for when master is unavailable</small>
                </div>

                <div class="action-buttons">
                    <button type="submit" class="btn btn-primary">Test Connection & Continue →</button>
                </div>
            </form>

            <div class="info-box">
                <h3>How to get an API key:</h3>
                <ol>
                    <li>Log in to master server: <a href="<?php echo htmlspecialchars($this->masterServerUrl); ?>/admin/" target="_blank"><?php echo htmlspecialchars($this->masterServerUrl); ?>/admin/</a></li>
                    <li>Go to <strong>System Settings → API Keys</strong></li>
                    <li>Click <strong>Generate New Client API Key</strong></li>
                    <li>Copy the 64-character key and paste it above</li>
                </ol>
            </div>
        </div>
        <?php

        $this->renderFooter();
    }

    private function performInstallation() {
        $this->renderHeader('Installing FlexPBX Client');

        if (empty($_SESSION['api_key'])) {
            echo '<div class="alert alert-error">API key not configured. Please go back.</div>';
            echo '<a href="?step=configure" class="btn btn-secondary">← Back</a>';
            $this->renderFooter();
            return;
        }

        $detectedServices = $_SESSION['detected_services'] ?? [];
        $apiKey = $_SESSION['api_key'];

        echo '<div class="install-section">';
        echo '<h2>Installing FlexPBX Client...</h2>';
        echo '<div class="progress-container">';

        // Register with master server
        $this->logProgress("Registering with master server...");
        $registration = $this->registerWithMaster($apiKey, $detectedServices);
        if (!$registration['success']) {
            $this->logProgress("❌ Registration failed: " . ($registration['error'] ?? 'Unknown error'));
            echo '</div></div>';
            $this->renderFooter();
            return;
        }
        $this->logProgress("✅ Registered successfully (Client ID: " . ($registration['client_id'] ?? 'unknown') . ")");

        // Download available modules
        $this->logProgress("Downloading module catalog from master server...");
        $config = $this->downloadConfiguration($registration['api_key'] ?? $apiKey);
        if ($config['success']) {
            $modules = $config['modules'] ?? [];
            $this->logProgress("✅ Found " . count($modules) . " available modules");

            // Install core modules automatically
            $coreModules = array_filter($modules, fn($m) => ($m['category'] ?? '') === 'core');
            $this->logProgress("Installing " . count($coreModules) . " core modules...");

            foreach ($coreModules as $module) {
                $moduleKey = $module['module_key'] ?? '';
                if ($moduleKey) {
                    if ($this->installModule($registration['api_key'] ?? $apiKey, $moduleKey)) {
                        $this->logProgress("✅ Installed {$module['module_name']}");
                    } else {
                        $this->logProgress("⚠️  Failed to install {$module['module_name']}");
                    }
                }
            }
        }

        // Install only detected service hooks
        if (isset($detectedServices['cpanel']['installed'])) {
            $this->logProgress("Installing cPanel/WHM hooks...");
            if ($this->promptUser("Install cPanel/WHM integration hooks?")) {
                $this->installCPanelHooks();
                $this->logProgress("✅ cPanel hooks installed");
            } else {
                $this->logProgress("⏭️  Skipped cPanel hooks");
            }
        }

        if (isset($detectedServices['whmcs']['installed'])) {
            $this->logProgress("Installing WHMCS module...");
            if ($this->promptUser("Install WHMCS FlexPBX module?")) {
                $this->installWHMCSModule($detectedServices['whmcs']['path']);
                $this->logProgress("✅ WHMCS module installed");
            } else {
                $this->logProgress("⏭️  Skipped WHMCS module");
            }
        }

        if (isset($detectedServices['wordpress']['installed'])) {
            $this->logProgress("Installing WordPress plugin...");
            if ($this->promptUser("Install WordPress FlexPBX plugin for " . $detectedServices['wordpress']['count'] . " site(s)?")) {
                $this->installWordPressPlugin($detectedServices['wordpress']['paths']);
                $this->logProgress("✅ WordPress plugin installed");
            } else {
                $this->logProgress("⏭️  Skipped WordPress plugin");
            }
        }

        if (isset($detectedServices['composr']['installed'])) {
            $this->logProgress("Installing Composr addon...");
            if ($this->promptUser("Install Composr FlexPBX addon?")) {
                $this->installComposrAddon($detectedServices['composr']['path']);
                $this->logProgress("✅ Composr addon installed");
            } else {
                $this->logProgress("⏭️  Skipped Composr addon");
            }
        }

        // Install core FlexPBX client files
        $this->logProgress("Installing FlexPBX client core files...");
        $this->installClientCore($apiKey);
        $this->logProgress("✅ Core files installed");

        // Set up automatic updates
        $this->logProgress("Configuring automatic updates...");
        $this->setupAutoUpdates($apiKey);
        $this->logProgress("✅ Auto-updates configured");

        echo '</div>';
        echo '<div class="alert alert-success">';
        echo '<h3>🎉 Installation Complete!</h3>';
        echo '<p>Your server is now connected to the FlexPBX master server.</p>';
        echo '</div>';

        echo '<div class="action-buttons">';
        echo '<a href="?step=complete" class="btn btn-primary">View Summary →</a>';
        echo '</div>';

        echo '</div>';
        $this->renderFooter();
    }

    private function showComplete() {
        $detectedServices = $_SESSION['detected_services'] ?? [];
        $this->renderHeader('Installation Complete');

        ?>
        <div class="complete-section">
            <h2>✅ Installation Complete</h2>

            <div class="success-box">
                <h3>Your FlexPBX client is ready!</h3>
                <p>This server is now connected to: <strong><?php echo htmlspecialchars($this->masterServerUrl); ?></strong></p>
            </div>

            <div class="installed-components">
                <h3>Installed Components</h3>
                <ul>
                    <li>✅ FlexPBX Client Core</li>
                    <li>✅ Automatic Update System</li>
                    <li>✅ Master Server API Connection</li>
                    <?php if (isset($detectedServices['cpanel']['installed'])): ?>
                        <li>✅ cPanel/WHM Integration Hooks</li>
                    <?php endif; ?>
                    <?php if (isset($detectedServices['whmcs']['installed'])): ?>
                        <li>✅ WHMCS FlexPBX Module</li>
                    <?php endif; ?>
                    <?php if (isset($detectedServices['wordpress']['installed'])): ?>
                        <li>✅ WordPress FlexPBX Plugin (<?php echo $detectedServices['wordpress']['count']; ?> site(s))</li>
                    <?php endif; ?>
                    <?php if (isset($detectedServices['composr']['installed'])): ?>
                        <li>✅ Composr FlexPBX Addon</li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="next-steps">
                <h3>Next Steps</h3>
                <ol>
                    <li><strong>Delete this installer</strong> for security:
                        <code>rm -f <?php echo __FILE__; ?></code>
                    </li>
                    <li>Updates will be automatically downloaded from the master server</li>
                    <li>Check configuration in the admin panel</li>
                    <li>Configure service-specific settings as needed</li>
                </ol>
            </div>

            <div class="action-buttons">
                <a href="../admin/" class="btn btn-primary">Go to Admin Panel →</a>
                <button onclick="deleteInstaller()" class="btn btn-danger">Delete Installer</button>
            </div>
        </div>

        <script>
        function deleteInstaller() {
            if (confirm('⚠️ Delete this installer file?\n\nThis cannot be undone.')) {
                fetch('?action=delete_installer', {method: 'POST'})
                    .then(response => response.text())
                    .then(result => {
                        if (result === 'OK') {
                            alert('✅ Installer deleted!');
                            window.location.href = '../admin/';
                        } else {
                            alert('⚠️ Could not delete - please remove manually');
                        }
                    });
            }
        }
        </script>
        <?php

        $this->renderFooter();
    }

    // Helper methods

    private function testMasterServerConnection($apiKey) {
        $url = $this->masterServerUrl . MASTER_API_ENDPOINT . '/health';

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $apiKey,
                'User-Agent: FlexPBX-Client-Installer/1.0',
            ],
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            return ['success' => true];
        } else {
            return ['success' => false, 'error' => "HTTP {$httpCode}"];
        }
    }

    private function registerWithMaster($apiKey, $services) {
        $url = $this->masterServerUrl . MASTER_API_ENDPOINT . '/clients.php?path=register';

        $data = [
            'server_url' => $_SERVER['HTTP_HOST'] ?? 'unknown',
            'admin_email' => $_SESSION['admin_email'] ?? '',
            'installation_type' => 'universal',
            'version' => '1.0',
            'distro_id' => $services['distro']['id'] ?? 'unknown',
            'distro_version' => $services['distro']['version'] ?? 'unknown',
            'php_version' => phpversion(),
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'User-Agent: FlexPBX-Client-Installer/1.0',
            ],
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode === 200 || $httpCode === 201) {
            $result = json_decode($response, true);
            if (isset($result['success']) && $result['success']) {
                return [
                    'success' => true,
                    'client_id' => $result['client_id'] ?? null,
                    'api_key' => $result['api_key'] ?? null,
                ];
            }
        }

        return [
            'success' => false,
            'error' => $error ?: "Registration failed: HTTP {$httpCode}",
        ];
    }

    private function downloadConfiguration($apiKey) {
        $url = $this->masterServerUrl . MASTER_API_ENDPOINT . '/modules.php?path=available';

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'X-API-KEY: ' . $apiKey,
                'User-Agent: FlexPBX-Client-Installer/1.0',
            ],
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            $result = json_decode($response, true);
            if (isset($result['success']) && $result['success']) {
                return [
                    'success' => true,
                    'modules' => $result['modules'] ?? [],
                ];
            }
        }

        return ['success' => false, 'modules' => []];
    }

    private function installModule($apiKey, $moduleKey) {
        $url = $this->masterServerUrl . MASTER_API_ENDPOINT . '/modules.php?path=install';

        $data = json_encode(['module_key' => $moduleKey]);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-API-KEY: ' . $apiKey,
                'User-Agent: FlexPBX-Client-Installer/1.0',
            ],
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            $result = json_decode($response, true);
            return isset($result['success']) && $result['success'];
        }

        return false;
    }

    private function promptUser($message) {
        // In real implementation, this would be interactive
        // For now, return true (install all detected)
        return true;
    }

    private function installCPanelHooks() {
        // Install cPanel hooks that connect to master server
    }

    private function installWHMCSModule($path) {
        // Install WHMCS module
    }

    private function installWordPressPlugin($paths) {
        // Install WordPress plugin
    }

    private function installComposrAddon($path) {
        // Install Composr addon
    }

    private function installClientCore($apiKey) {
        // Install core client files
    }

    private function setupAutoUpdates($apiKey) {
        // Set up cron for automatic updates
    }

    private function logProgress($message) {
        echo "<div class='log-entry'>" . htmlspecialchars($message) . "</div>";
        flush();
        ob_flush();
        usleep(100000); // 0.1 second delay for visual effect
    }

    private function renderHeader($title) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo htmlspecialchars($title); ?></title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
                .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); padding: 40px; }
                h2 { color: #333; margin-bottom: 20px; }
                .info-box, .server-info, .detection-summary, .success-box { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea; }
                .alert-error { background: #fee; border-left-color: #f44; }
                .alert-success { background: #efe; border-left-color: #4a4; }
                .btn { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 6px; border: none; cursor: pointer; font-size: 16px; }
                .btn-secondary { background: #6c757d; }
                .btn-danger { background: #dc3545; }
                .btn:hover { opacity: 0.9; }
                .action-buttons { margin-top: 30px; text-align: center; }
                .action-buttons .btn { margin: 0 10px; }
                .progress-container { background: #f8f9fa; padding: 20px; border-radius: 8px; max-height: 400px; overflow-y: auto; }
                .log-entry { padding: 8px; border-bottom: 1px solid #eee; font-family: monospace; font-size: 14px; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
                th { background: #f8f9fa; font-weight: 600; }
                .form-group { margin: 20px 0; }
                .form-group label { display: block; margin-bottom: 8px; font-weight: 600; }
                .form-group input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
                .form-group small { display: block; margin-top: 4px; color: #666; font-size: 13px; }
                .required { color: #f44; }
                .readonly { background: #f8f9fa; }
            </style>
        </head>
        <body>
            <div class="container">
        <?php
    }

    private function renderFooter() {
        ?>
            </div>
        </body>
        </html>
        <?php
    }
}

// Handle delete installer action
if (isset($_GET['action']) && $_GET['action'] === 'delete_installer') {
    if (unlink(__FILE__)) {
        echo 'OK';
    } else {
        echo 'ERROR';
    }
    exit;
}

// Run installer
$installer = new FlexPBXClientInstaller();
$installer->run();
