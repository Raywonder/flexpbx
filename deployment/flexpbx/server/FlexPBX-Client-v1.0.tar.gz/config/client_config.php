<?php
/**
 * FlexPBX Client Configuration
 * This client connects to the master server for updates and management
 */

return [
    'master_server' => [
        'url' => 'https://flexpbx.devinecreations.net',
        'api_endpoint' => '/api',
        'api_key' => '', // Get from master server admin panel
    ],

    'hubnode' => [
        'url' => '', // Optional fallback
        'api_key' => '',
    ],

    'auto_update' => [
        'enabled' => true,
        'check_interval' => 86400, // 24 hours
        'auto_install' => false,   // Require manual approval
    ],

    'features' => [
        'detect_cpanel' => true,
        'detect_whmcs' => true,
        'detect_wordpress' => true,
        'detect_composr' => true,
        'install_hooks_auto' => false, // Prompt before installing
    ],
];
