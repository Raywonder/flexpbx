# FlexPBX Homebrew Support

FlexPBX installers include Homebrew (Linuxbrew) support as a fallback package manager. This is useful when:
- Native package managers don't have required packages
- You need newer versions than available in distro repos
- Installing on servers without root access
- Working on non-standard Linux distributions

## What is Homebrew?

Homebrew is a popular package manager originally from macOS, now available on Linux as "Linuxbrew". It can install packages in user space without requiring root privileges.

**Official Site:** https://brew.sh

## Automatic Installation

The FlexPBX installer can automatically install Homebrew if needed:

```php
require_once 'includes/HomebrewHelper.php';

$homebrew = new HomebrewHelper();

if (!$homebrew->isInstalled()) {
    echo "Homebrew not found. Installing...\n";
    $result = $homebrew->install();

    if ($result['success']) {
        echo "✅ " . $result['message'] . "\n";
    } else {
        echo "❌ " . $result['message'] . "\n";
    }
}
```

## Manual Installation

If you prefer to install Homebrew manually before running the FlexPBX installer:

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

After installation, add Homebrew to your PATH:

```bash
# For bash
echo 'eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"' >> ~/.bashrc
source ~/.bashrc

# For zsh
echo 'eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"' >> ~/.zshrc
source ~/.zshrc
```

## Using Homebrew with FlexPBX

### Check if Homebrew is Installed

```php
$homebrew = new HomebrewHelper();

if ($homebrew->isInstalled()) {
    echo "Homebrew is installed at: " . $homebrew->getPath() . "\n";
    echo "Prefix: " . $homebrew->getPrefix() . "\n";
} else {
    echo "Homebrew is not installed\n";
}
```

### Install Packages

```php
$homebrew = new HomebrewHelper();

// Install a single package
$result = $homebrew->installPackage('php');
if ($result['success']) {
    echo "✅ PHP installed\n";
}

// Install multiple packages
$packages = ['mariadb', 'nginx', 'coturn', 'git'];
foreach ($packages as $package) {
    $result = $homebrew->installPackage($package);
    echo $result['message'] . "\n";
}
```

### Check if Package is Installed

```php
$homebrew = new HomebrewHelper();

if ($homebrew->isPackageInstalled('asterisk')) {
    echo "Asterisk is installed via Homebrew\n";
} else {
    echo "Asterisk not found\n";
}
```

### Update Homebrew and Packages

```php
$homebrew = new HomebrewHelper();

$result = $homebrew->update();
if ($result['success']) {
    echo "✅ Homebrew updated\n";
}
```

### Get Recommended Packages

```php
$homebrew = new HomebrewHelper();

$packages = $homebrew->getRecommendedPackages();
foreach ($packages as $name => $description) {
    echo "$name: $description\n";
}
```

## Recommended Packages for FlexPBX

The following packages are recommended for a complete FlexPBX installation:

| Package | Description | Required |
|---------|-------------|----------|
| php | PHP 8.1+ | ✅ Yes |
| mariadb | Database server | ✅ Yes |
| nginx | Web server (alternative to Apache) | ⚠️ One of Apache/Nginx |
| apache2 | Web server (alternative to Nginx) | ⚠️ One of Apache/Nginx |
| asterisk | PBX system | ✅ Yes |
| coturn | STUN/TURN server for NAT | ⚠️ Recommended |
| git | Version control | ⚠️ Recommended |
| curl | HTTP client | ⚠️ Recommended |
| wget | File downloader | ⚠️ Recommended |
| openssl | SSL/TLS toolkit | ⚠️ Recommended |

## Troubleshooting

### Homebrew Installation Fails

If automatic installation fails, install manually:

```bash
# Install build dependencies first (Ubuntu/Debian)
sudo apt-get install build-essential procps curl file git

# Install build dependencies (RHEL/Fedora/AlmaLinux)
sudo dnf groupinstall 'Development Tools'
sudo dnf install procps-ng curl file git

# Then install Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Package Not Found in Homebrew

Not all packages are available in Homebrew. If a package isn't available:

1. Use your system's native package manager (dnf/yum/apt)
2. Compile from source
3. Check alternative package names

### Permission Errors

Homebrew should be installed in user space. If you get permission errors:

```bash
# Fix Homebrew permissions
sudo chown -R $(whoami) /home/linuxbrew/.linuxbrew

# Or install in your home directory
curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh | \
    HOMEBREW_PREFIX=$HOME/.linuxbrew bash
```

### PATH Not Set

If `brew` command not found after installation:

```bash
# Check where Homebrew was installed
ls -la /home/linuxbrew/.linuxbrew/bin/brew
ls -la ~/.linuxbrew/bin/brew

# Add to PATH manually
export PATH="/home/linuxbrew/.linuxbrew/bin:$PATH"

# Make permanent
echo 'eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"' >> ~/.bashrc
source ~/.bashrc
```

## Diagnostic Information

Get complete Homebrew diagnostics:

```php
$homebrew = new HomebrewHelper();

$diagnostics = $homebrew->getDiagnostics();
print_r($diagnostics);
```

Output example:
```
Array
(
    [installed] => 1
    [path] => /home/linuxbrew/.linuxbrew/bin/brew
    [prefix] => /home/linuxbrew/.linuxbrew
    [version] => Homebrew 4.1.20
    [packages_installed] => 42
    [outdated_packages] => Array
        (
            [0] => php (8.2.10 -> 8.2.12)
            [1] => git (2.42.0 -> 2.43.0)
        )
)
```

## Integration with FlexPBX Installer

The FlexPBX installer automatically:

1. **Detects** if Homebrew is installed
2. **Offers to install** Homebrew if missing (on compatible systems)
3. **Uses as fallback** when native package manager fails
4. **Reports status** in installation logs

Example installation flow:

```
FlexPBX Installation
====================

[1/5] Detecting environment...
✅ OS: Ubuntu 22.04 LTS
✅ Package Manager: apt
❌ Homebrew: Not found

[2/5] Installing dependencies...
⚠️  Package 'asterisk' not found in apt
ℹ️  Would you like to install Homebrew as a fallback? (y/n): y

[3/5] Installing Homebrew...
✅ Homebrew installed at /home/linuxbrew/.linuxbrew

[4/5] Installing packages via Homebrew...
✅ asterisk installed
✅ coturn installed

[5/5] Configuring FlexPBX...
✅ Installation complete!
```

## Best Practices

1. **Use native packages first** - Only use Homebrew as fallback
2. **Keep updated** - Run `brew update` and `brew upgrade` regularly
3. **Check compatibility** - Not all Homebrew packages work perfectly on all Linux distros
4. **Monitor disk space** - Homebrew can use significant disk space with dependencies
5. **Document installations** - Keep track of what was installed via Homebrew vs native package manager

## Security Considerations

- Homebrew downloads packages from GitHub releases and third-party taps
- Always verify package sources when possible
- Keep Homebrew updated for security patches
- Be cautious with unofficial "taps" (third-party repositories)
- Review package formulas before installing: `brew info <package>`

## Additional Resources

- **Homebrew Documentation:** https://docs.brew.sh
- **Linux Installation:** https://docs.brew.sh/Homebrew-on-Linux
- **Package Search:** https://formulae.brew.sh
- **Troubleshooting:** https://docs.brew.sh/Troubleshooting

## Support

For FlexPBX-specific Homebrew issues:
- Check FlexPBX documentation
- Review installation logs
- Contact FlexPBX support

For general Homebrew issues:
- Visit: https://github.com/Homebrew/brew/issues
- Community: https://discourse.brew.sh
