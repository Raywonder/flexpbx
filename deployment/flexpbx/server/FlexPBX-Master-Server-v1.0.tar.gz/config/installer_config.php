<?php
/**
 * FlexPBX v1.0 Installer Configuration
 *
 * This file controls installer behavior for different deployment scenarios:
 * - Standalone Installation: Self-contained FlexPBX server
 * - Remote Installation: Connects to main FlexPBX server for updates
 * - HubNode Integration: Links to HubNode API for centralized management
 */

return [
    // ============================================
    // Installation Type
    // ============================================
    'installation_type' => 'standalone', // Options: 'standalone', 'remote', 'hubnode'

    // ============================================
    // Main FlexPBX Server (for remote installations)
    // ============================================
    'main_server' => [
        'enabled' => false,
        'url' => '', // e.g., 'https://flexpbx-main.example.com'
        'api_endpoint' => '/api',
        'update_check_url' => '/api/updates/check',
        'update_download_url' => '/api/updates/download',
        'registration_url' => '/api/clients/register',
        'auth_method' => 'api_key', // Options: 'api_key', 'oauth', 'none'
        'verify_ssl' => true,
        'timeout' => 30,
    ],

    // ============================================
    // HubNode API Integration
    // ============================================
    'hubnode' => [
        'enabled' => false,
        'url' => '', // e.g., 'https://hubnode.example.com'
        'api_endpoint' => '/api/v1',
        'events_endpoint' => '/api/v1/events',
        'auth_endpoint' => '/api/v1/auth',
        'verify_ssl' => true,
        'timeout' => 30,
        'features' => [
            'event_logging' => true,
            'centralized_auth' => false,
            'multi_tenant' => false,
        ],
    ],

    // ============================================
    // Update Management
    // ============================================
    'updates' => [
        'auto_check' => false,
        'check_interval' => 86400, // 24 hours in seconds
        'auto_install' => false,
        'backup_before_update' => true,
        'rollback_enabled' => true,
        'update_channel' => 'stable', // Options: 'stable', 'beta', 'dev'
    ],

    // ============================================
    // Multi-Client Management
    // ============================================
    'multi_client' => [
        'enabled' => false,
        'allow_registration' => true,
        'require_approval' => true,
        'max_clients' => 100,
        'client_isolation' => true, // Separate databases per client
        'shared_resources' => false, // Share extensions/DIDs between clients
    ],

    // ============================================
    // Database Settings
    // ============================================
    'database' => [
        'driver' => 'mysql',
        'default_port' => 3306,
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '', // Table prefix if needed
        'pool_size' => 10,
    ],

    // ============================================
    // Security Settings
    // ============================================
    'security' => [
        'require_https' => false, // Set to true in production
        'session_lifetime' => 3600,
        'password_min_length' => 12,
        'api_key_length' => 64,
        'encryption_method' => 'AES-256-CBC',
        'hash_algorithm' => 'bcrypt',
    ],

    // ============================================
    // Feature Flags
    // ============================================
    'features' => [
        'auto_provisioning' => true,
        'call_center' => true,
        'accessibility' => true,
        'mastodon_integration' => true,
        'discord_notifications' => true,
        'email_notifications' => true,
        'department_management' => true,
        'role_management' => true,
    ],

    // ============================================
    // Default Configuration Values
    // ============================================
    'defaults' => [
        'admin_username' => 'admin',
        'admin_email' => 'admin@localhost',
        'admin_extension' => '2000',
        'system_email_from' => 'noreply@localhost',
        'system_email_name' => 'FlexPBX',
        'timezone' => 'America/New_York',
        'language' => 'en_US',
    ],

    // ============================================
    // API Settings
    // ============================================
    'api' => [
        'version' => 'v1',
        'base_path' => '/api',
        'rate_limiting' => [
            'enabled' => true,
            'max_requests' => 100,
            'time_window' => 60, // seconds
        ],
        'cors' => [
            'enabled' => false,
            'allowed_origins' => [],
            'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE'],
        ],
    ],

    // ============================================
    // Logging Settings
    // ============================================
    'logging' => [
        'level' => 'INFO', // Options: 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
        'log_path' => '/var/log/flexpbx',
        'max_file_size' => 10485760, // 10MB
        'max_files' => 5,
        'log_to_syslog' => false,
        'log_to_file' => true,
    ],

    // ============================================
    // Asterisk Integration
    // ============================================
    'asterisk' => [
        'config_path' => '/etc/asterisk',
        'reload_on_change' => true,
        'ami_enabled' => true,
        'ami_host' => 'localhost',
        'ami_port' => 5038,
        'pjsip_enabled' => true,
        'voicemail_enabled' => true,
    ],

    // ============================================
    // System Requirements
    // ============================================
    'requirements' => [
        'php_min_version' => '7.4',
        'asterisk_min_version' => '16.0',
        'mysql_min_version' => '5.7',
        'required_extensions' => [
            'pdo',
            'pdo_mysql',
            'json',
            'mbstring',
            'curl',
            'openssl',
        ],
        'supported_os' => [
            'rhel' => ['8', '9'],
            'almalinux' => ['8', '9'],
            'rocky' => ['8', '9'],
            'centos' => ['7', '8', 'stream'],
            'ubuntu' => ['18.04', '20.04', '22.04', '24.04'],
            'debian' => ['10', '11', '12'],
            'fedora' => ['36', '37', '38', '39'],
        ],
    ],

    // ============================================
    // Distribution-Specific Settings
    // ============================================
    'distro_config' => [
        'package_manager' => 'auto', // Options: 'auto', 'dnf', 'yum', 'apt', 'apt-get'
        'service_manager' => 'systemd', // Options: 'systemd', 'sysvinit', 'upstart'
        'asterisk_config_path' => '/etc/asterisk',
        'apache_config_path' => [
            'rhel' => '/etc/httpd',
            'ubuntu' => '/etc/apache2',
            'debian' => '/etc/apache2',
        ],
        'apache_service_name' => [
            'rhel' => 'httpd',
            'ubuntu' => 'apache2',
            'debian' => 'apache2',
        ],
        'php_package_names' => [
            'rhel' => 'php',
            'ubuntu' => 'php-fpm',
            'debian' => 'php-fpm',
        ],
    ],
];
