# FlexPBX v1.0 Official Installer

Enterprise-grade PBX management system with multi-client support, auto-provisioning, and centralized update management.

## Features

- **Web-Based Installer**: Beautiful, accessible installation wizard
- **HubNode Integration**: Connect to HubNode API for centralized management
- **Update Management**: Automatic updates from main FlexPBX server
- **Multi-Client Support**: Manage multiple client installations
- **Auto-Provisioning**: Automatic user setup with all features enabled
- **Call Center Tools**: Queue management, agent monitoring, supervisor tools
- **Accessibility**: WCAG 2.1 AA/AAA compliant interface
- **Notifications**: Discord, Mastodon, Email, and Push notifications
- **Department Management**: Team-based or single-person departments

## Installation Types

### 1. Standalone Installation
Self-contained FlexPBX server without external dependencies.

### 2. Remote Installation
Connects to main FlexPBX server for updates and centralized management.

### 3. HubNode Integration
Links to HubNode API for multi-platform management and event logging.

## Requirements

- **Operating System**: Linux (systemd-based distributions)
  - RHEL/AlmaLinux/Rocky Linux 8+, 9+
  - Ubuntu 18.04, 20.04, 22.04, 24.04
  - Debian 10 (Buster), 11 (Bullseye), 12 (Bookworm)
  - CentOS 7, 8, Stream
  - Fedora 36+
  - Other modern Linux distributions with systemd
- **Web Server**: Apache 2.4+ with mod_rewrite
  - Package: `httpd` (RHEL/CentOS/Fedora) or `apache2` (Ubuntu/Debian)
- **PHP**: 7.4+ with extensions:
  - pdo, pdo_mysql
  - json, mbstring
  - curl, openssl
  - zip (optional)
  - Package: `php` (RHEL-based) or `php-fpm` (Debian-based)
- **Database**: MySQL 5.7+ / MariaDB 10.3+
  - Package: `mariadb-server` or `mysql-server`
- **Asterisk**: 16.0+ with PJSIP
  - Package: `asterisk` (from distribution repos or compiled)

## Quick Start

### 1. Upload Installer

Upload all files to your web server:

```bash
/var/www/html/flexpbx/
  ├── api/
  │   └── install.php
  ├── config/
  │   ├── installer_config.php
  │   └── database_schemas.sql
  └── includes/
      ├── HubNodeConnector.php
      └── UpdateManager.php
```

### 2. Configure Installation Type

Edit `config/installer_config.php`:

```php
// For standalone installation
'installation_type' => 'standalone',

// For remote installation (connects to main server)
'installation_type' => 'remote',
'main_server' => [
    'enabled' => true,
    'url' => 'https://your-main-flexpbx-server.com',
    'api_key' => 'your-api-key-here',
],

// For HubNode integration
'installation_type' => 'hubnode',
'hubnode' => [
    'enabled' => true,
    'url' => 'https://your-hubnode-server.com',
    'api_key' => 'your-hubnode-api-key',
],
```

### 3. Run Web Installer

Navigate to: `https://your-server.com/flexpbx/api/install.php`

Follow the installation wizard:
1. **Welcome** - Introduction and installation type selection
2. **Requirements** - System requirements check
3. **Database** - Database configuration and connection
4. **Installation** - Install database schema and default data
5. **Complete** - Finish and access admin panel

### 4. Delete Installer

For security, delete the installer after successful installation:

```bash
rm -f /var/www/html/flexpbx/api/install.php
```

## Configuration

### Main Server Registration

For remote installations, the installer will automatically register with the main FlexPBX server during installation. You can also manually register later:

```php
require_once 'includes/UpdateManager.php';

$config = include 'config/installer_config.php';
$updateManager = new UpdateManager($config);

$result = $updateManager->registerWithMainServer([
    'admin_email' => 'admin@example.com',
    'features' => ['auto_provisioning', 'call_center'],
]);
```

### HubNode Registration

To register with HubNode API:

```php
require_once 'includes/HubNodeConnector.php';

$config = include 'config/installer_config.php';
$hubnode = new HubNodeConnector($config);

$result = $hubnode->registerInstallation([
    'version' => '1.0',
    'server_url' => 'https://your-server.com',
    'admin_email' => 'admin@example.com',
    'features' => ['auto_provisioning', 'call_center'],
]);
```

## Update Management

### Checking for Updates

```php
$updateManager = new UpdateManager($config);
$updates = $updateManager->checkForUpdates();

if ($updates['update_available']) {
    echo "Update available: " . $updates['latest_version'];
}
```

### Installing Updates

```php
// Download update
$download = $updateManager->downloadUpdate($updates);

// Install update (creates backup first if configured)
$result = $updateManager->installUpdate($download['filename']);
```

### Rolling Back

```php
// Rollback to most recent backup
$result = $updateManager->rollback();

// List available backups
$backups = $updateManager->listBackups();
```

## Auto-Provisioning

FlexPBX automatically provisions new users with:

- Next available extension (e.g., 3000, 3001, 3002...)
- Auto-generated voicemail PIN
- PJSIP endpoint configuration
- Main DID assignment (shared access)
- All features enabled by default:
  - Voicemail
  - Email notifications
  - Call recording
  - Accessibility features

### Configuring Auto-Provisioning

Settings are managed via admin panel: **Admin → System Settings → Auto-Provisioning**

Or directly in database table `provisioning_settings`:

```sql
UPDATE provisioning_settings
SET setting_value = '4000'
WHERE setting_key = 'extension_range_start';
```

## API Endpoints

### System API
- `GET /api/system.php?path=health` - Health check
- `GET /api/system.php?path=full_status` - Full system status
- `POST /api/system.php?path=backup_create` - Create backup

### Users API
- `GET /api/users.php` - List all users
- `POST /api/users.php` - Create new user (auto-provisions)
- `PUT /api/users.php?id=123` - Update user
- `DELETE /api/users.php?id=123` - Delete user

### Extensions API
- `GET /api/extensions.php` - List extensions
- `GET /api/extensions.php?extension=2000` - Get extension details

### Updates API (Main Server Only)
- `POST /api/updates/check` - Check for updates
- `POST /api/updates/download` - Download update package
- `POST /api/clients/register` - Register new client

## HubNode API Integration

### Event Logging

```php
$hubnode = new HubNodeConnector($config);

$hubnode->logEvent('user_created', [
    'username' => 'john',
    'extension' => '3000',
    'role' => 'user',
], 'INFO');
```

### Authentication

```php
$result = $hubnode->authenticate([
    'username' => 'john',
    'password' => 'secure-password',
]);

if ($result['success']) {
    // User authenticated via HubNode
}
```

### Connectivity Check

```php
$status = $hubnode->checkConnection();

if ($status['success']) {
    echo "Connected to HubNode (latency: {$status['latency_ms']}ms)";
}
```

## Multi-Client Management

When running as main server, FlexPBX can manage multiple client installations:

1. Clients register during installation
2. Main server tracks client versions and features
3. Updates pushed to all registered clients
4. Centralized logging and monitoring

### Client Registration Approval

```sql
-- View pending client registrations
SELECT * FROM client_registrations WHERE status = 'pending';

-- Approve client
UPDATE client_registrations
SET status = 'approved', approved_at = NOW()
WHERE client_id = '...';
```

## Security

### API Keys

Generate secure API keys for client authentication:

```php
$apiKey = bin2hex(random_bytes(32)); // 64-character key
```

Store in `installer_config.php`:

```php
'main_server' => [
    'api_key' => 'your-64-character-api-key-here',
],
```

### HTTPS

**Always use HTTPS in production.** Set in config:

```php
'security' => [
    'require_https' => true,
],
```

### Delete Installer

Remove installer after successful installation to prevent unauthorized reinstallation.

## Troubleshooting

### Database Connection Failed

- Verify database credentials in installer
- Check MySQL/MariaDB is running: `systemctl status mariadb`
- Test connection: `mysql -u username -p database_name`

### Asterisk Not Detecting Extensions

- Verify PJSIP config: `asterisk -rx "pjsip show endpoints"`
- Reload Asterisk: `systemctl restart asterisk`
- Check logs: `tail -f /var/log/asterisk/messages`

### Update Download Failed

- Verify main server URL in config
- Check API key is correct
- Test connectivity: `curl https://main-server.com/api/updates/check`

### HubNode Connection Failed

- Verify HubNode URL and API key
- Check network connectivity
- Review HubNode logs for authentication errors

## Support

For support and documentation:

- GitHub Issues: [Report a bug](https://github.com/yourusername/flexpbx/issues)
- Documentation: [https://docs.flexpbx.com](https://docs.flexpbx.com)
- Email: support@example.com

## License

Copyright © 2025 FlexPBX Development Team. All rights reserved.

## Changelog

### v1.0 (2025-10-17)
- Initial release
- Web-based installer with accessibility support
- HubNode API integration
- Update management system
- Multi-client support
- Auto-provisioning system
- Call center features
- Department management
- Comprehensive notification system
