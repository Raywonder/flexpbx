<?php
/**
 * Homebrew (Linuxbrew) Helper
 *
 * Provides fallback package management using Homebrew on Linux systems.
 * Useful when native package managers don't have required packages.
 *
 * @package FlexPBX
 * @version 1.0
 */

class HomebrewHelper {
    private $homebrewPath = null;
    private $homebrewPrefix = null;
    private $isInstalled = false;

    public function __construct() {
        $this->detect();
    }

    /**
     * Detect if Homebrew is installed
     */
    public function detect() {
        // Check common Homebrew locations
        $paths = [
            '/home/linuxbrew/.linuxbrew/bin/brew',
            getenv('HOME') . '/.linuxbrew/bin/brew',
            '/usr/local/bin/brew',
            '/opt/homebrew/bin/brew',
        ];

        foreach ($paths as $path) {
            if (file_exists($path) && is_executable($path)) {
                $this->homebrewPath = $path;
                $this->homebrewPrefix = dirname(dirname($path));
                $this->isInstalled = true;
                return true;
            }
        }

        // Check in PATH
        exec('which brew 2>/dev/null', $output, $returnCode);
        if ($returnCode === 0 && !empty($output[0])) {
            $this->homebrewPath = trim($output[0]);
            $this->homebrewPrefix = dirname(dirname($this->homebrewPath));
            $this->isInstalled = true;
            return true;
        }

        return false;
    }

    /**
     * Check if Homebrew is installed
     */
    public function isInstalled() {
        return $this->isInstalled;
    }

    /**
     * Get Homebrew installation path
     */
    public function getPath() {
        return $this->homebrewPath;
    }

    /**
     * Get Homebrew prefix (installation directory)
     */
    public function getPrefix() {
        return $this->homebrewPrefix;
    }

    /**
     * Install Homebrew
     *
     * @return array ['success' => bool, 'message' => string]
     */
    public function install() {
        if ($this->isInstalled) {
            return ['success' => true, 'message' => 'Homebrew is already installed'];
        }

        // Homebrew installation script
        $installScript = 'https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh';

        // Download and run installer
        exec('bash -c "$(curl -fsSL ' . $installScript . ')" 2>&1', $output, $returnCode);

        if ($returnCode === 0) {
            // Re-detect after installation
            $this->detect();

            if ($this->isInstalled) {
                return [
                    'success' => true,
                    'message' => 'Homebrew installed successfully at ' . $this->homebrewPrefix,
                    'path' => $this->homebrewPath,
                ];
            }
        }

        return [
            'success' => false,
            'message' => 'Failed to install Homebrew: ' . implode("\n", $output),
        ];
    }

    /**
     * Install a package using Homebrew
     *
     * @param string $package Package name
     * @return array ['success' => bool, 'message' => string]
     */
    public function installPackage($package) {
        if (!$this->isInstalled) {
            return [
                'success' => false,
                'message' => 'Homebrew is not installed',
            ];
        }

        // Check if package is already installed
        if ($this->isPackageInstalled($package)) {
            return [
                'success' => true,
                'message' => "$package is already installed",
            ];
        }

        // Install package
        exec($this->homebrewPath . ' install ' . escapeshellarg($package) . ' 2>&1', $output, $returnCode);

        if ($returnCode === 0) {
            return [
                'success' => true,
                'message' => "$package installed successfully via Homebrew",
                'output' => implode("\n", $output),
            ];
        }

        return [
            'success' => false,
            'message' => "Failed to install $package: " . implode("\n", $output),
        ];
    }

    /**
     * Check if a package is installed
     *
     * @param string $package Package name
     * @return bool
     */
    public function isPackageInstalled($package) {
        if (!$this->isInstalled) {
            return false;
        }

        exec($this->homebrewPath . ' list ' . escapeshellarg($package) . ' 2>/dev/null', $output, $returnCode);
        return $returnCode === 0;
    }

    /**
     * Update Homebrew and all packages
     *
     * @return array ['success' => bool, 'message' => string]
     */
    public function update() {
        if (!$this->isInstalled) {
            return [
                'success' => false,
                'message' => 'Homebrew is not installed',
            ];
        }

        // Update Homebrew itself
        exec($this->homebrewPath . ' update 2>&1', $updateOutput, $updateCode);

        // Upgrade all packages
        exec($this->homebrewPath . ' upgrade 2>&1', $upgradeOutput, $upgradeCode);

        if ($updateCode === 0 && $upgradeCode === 0) {
            return [
                'success' => true,
                'message' => 'Homebrew updated successfully',
                'output' => implode("\n", array_merge($updateOutput, $upgradeOutput)),
            ];
        }

        return [
            'success' => false,
            'message' => 'Failed to update Homebrew',
            'output' => implode("\n", array_merge($updateOutput, $upgradeOutput)),
        ];
    }

    /**
     * Get list of useful packages for FlexPBX
     *
     * @return array Package names that FlexPBX might need
     */
    public function getRecommendedPackages() {
        return [
            'php' => 'PHP programming language',
            'mariadb' => 'MariaDB database server',
            'nginx' => 'Nginx web server',
            'apache2' => 'Apache web server',
            'asterisk' => 'Asterisk PBX (if available)',
            'coturn' => 'Coturn STUN/TURN server',
            'git' => 'Version control system',
            'curl' => 'Command-line HTTP client',
            'wget' => 'File downloader',
            'openssl' => 'SSL/TLS toolkit',
        ];
    }

    /**
     * Add Homebrew to PATH environment
     *
     * @return string Shell commands to add to .bashrc/.zshrc
     */
    public function getPathExport() {
        if (!$this->isInstalled) {
            return '';
        }

        return sprintf(
            'eval "$(%s shellenv)"',
            $this->homebrewPath
        );
    }

    /**
     * Get diagnostic information
     *
     * @return array Homebrew status and configuration
     */
    public function getDiagnostics() {
        $diagnostics = [
            'installed' => $this->isInstalled,
            'path' => $this->homebrewPath,
            'prefix' => $this->homebrewPrefix,
        ];

        if ($this->isInstalled) {
            // Get Homebrew version
            exec($this->homebrewPath . ' --version 2>&1', $versionOutput);
            $diagnostics['version'] = implode("\n", $versionOutput);

            // Get installed packages count
            exec($this->homebrewPath . ' list 2>&1 | wc -l', $countOutput);
            $diagnostics['packages_installed'] = (int)trim($countOutput[0] ?? 0);

            // Check for updates
            exec($this->homebrewPath . ' outdated 2>&1', $outdatedOutput);
            $diagnostics['outdated_packages'] = $outdatedOutput;
        }

        return $diagnostics;
    }
}
