<?php
/**
 * FlexPBX Distribution Detector
 *
 * Detects Linux distribution and provides distribution-specific
 * configuration for installer compatibility across multiple platforms.
 *
 * Supports:
 * - RHEL/AlmaLinux/Rocky Linux
 * - Ubuntu
 * - Debian
 * - CentOS
 * - Fedora
 * - Other systemd-based distributions
 *
 * @version 1.0
 * @package FlexPBX
 */

class DistroDetector {
    private $distroInfo = [];
    private $detectionMethods = [
        'os-release',
        'lsb-release',
        'redhat-release',
        'debian-version',
    ];

    public function __construct() {
        $this->detect();
    }

    /**
     * Detect current Linux distribution
     */
    private function detect() {
        // Try /etc/os-release (standard on modern distributions)
        if (file_exists('/etc/os-release')) {
            $this->parseOsRelease();
        }
        // Try /etc/lsb-release (Ubuntu/Debian)
        elseif (file_exists('/etc/lsb-release')) {
            $this->parseLsbRelease();
        }
        // Try /etc/redhat-release (RHEL/CentOS/Fedora)
        elseif (file_exists('/etc/redhat-release')) {
            $this->parseRedhatRelease();
        }
        // Try /etc/debian_version (Debian)
        elseif (file_exists('/etc/debian_version')) {
            $this->parseDebianVersion();
        }

        // Fallback detection via uname
        if (empty($this->distroInfo['id'])) {
            $this->distroInfo['id'] = 'linux';
            $this->distroInfo['name'] = 'Generic Linux';
            $this->distroInfo['version'] = trim(shell_exec('uname -r'));
        }

        // Detect package manager
        $this->detectPackageManager();

        // Detect service manager
        $this->detectServiceManager();
    }

    /**
     * Parse /etc/os-release
     */
    private function parseOsRelease() {
        $content = file_get_contents('/etc/os-release');
        $lines = explode("\n", $content);

        foreach ($lines as $line) {
            if (empty($line) || strpos($line, '=') === false) continue;

            list($key, $value) = explode('=', $line, 2);
            $value = trim($value, '"');

            switch ($key) {
                case 'ID':
                    $this->distroInfo['id'] = strtolower($value);
                    break;
                case 'ID_LIKE':
                    $this->distroInfo['id_like'] = strtolower($value);
                    break;
                case 'NAME':
                    $this->distroInfo['name'] = $value;
                    break;
                case 'VERSION_ID':
                    $this->distroInfo['version'] = $value;
                    break;
                case 'PRETTY_NAME':
                    $this->distroInfo['pretty_name'] = $value;
                    break;
            }
        }
    }

    /**
     * Parse /etc/lsb-release
     */
    private function parseLsbRelease() {
        $content = file_get_contents('/etc/lsb-release');
        $lines = explode("\n", $content);

        foreach ($lines as $line) {
            if (strpos($line, 'DISTRIB_ID=') === 0) {
                $this->distroInfo['id'] = strtolower(str_replace('DISTRIB_ID=', '', $line));
            } elseif (strpos($line, 'DISTRIB_RELEASE=') === 0) {
                $this->distroInfo['version'] = str_replace('DISTRIB_RELEASE=', '', $line);
            } elseif (strpos($line, 'DISTRIB_DESCRIPTION=') === 0) {
                $this->distroInfo['name'] = str_replace('DISTRIB_DESCRIPTION=', '', $line);
            }
        }
    }

    /**
     * Parse /etc/redhat-release
     */
    private function parseRedhatRelease() {
        $content = trim(file_get_contents('/etc/redhat-release'));

        if (stripos($content, 'CentOS') !== false) {
            $this->distroInfo['id'] = 'centos';
            $this->distroInfo['name'] = 'CentOS';
        } elseif (stripos($content, 'Red Hat') !== false || stripos($content, 'RHEL') !== false) {
            $this->distroInfo['id'] = 'rhel';
            $this->distroInfo['name'] = 'Red Hat Enterprise Linux';
        } elseif (stripos($content, 'AlmaLinux') !== false) {
            $this->distroInfo['id'] = 'almalinux';
            $this->distroInfo['name'] = 'AlmaLinux';
        } elseif (stripos($content, 'Rocky') !== false) {
            $this->distroInfo['id'] = 'rocky';
            $this->distroInfo['name'] = 'Rocky Linux';
        } elseif (stripos($content, 'Fedora') !== false) {
            $this->distroInfo['id'] = 'fedora';
            $this->distroInfo['name'] = 'Fedora';
        }

        // Extract version number
        if (preg_match('/release (\d+\.?\d*)/', $content, $matches)) {
            $this->distroInfo['version'] = $matches[1];
        }
    }

    /**
     * Parse /etc/debian_version
     */
    private function parseDebianVersion() {
        $this->distroInfo['id'] = 'debian';
        $this->distroInfo['name'] = 'Debian';
        $this->distroInfo['version'] = trim(file_get_contents('/etc/debian_version'));
    }

    /**
     * Detect package manager
     */
    private function detectPackageManager() {
        $managers = [
            'dnf' => '/usr/bin/dnf',
            'yum' => '/usr/bin/yum',
            'apt' => '/usr/bin/apt',
            'apt-get' => '/usr/bin/apt-get',
            'zypper' => '/usr/bin/zypper',
            'pacman' => '/usr/bin/pacman',
        ];

        foreach ($managers as $manager => $path) {
            if (file_exists($path)) {
                $this->distroInfo['package_manager'] = $manager;
                break;
            }
        }
    }

    /**
     * Detect service manager
     */
    private function detectServiceManager() {
        if (file_exists('/run/systemd/system')) {
            $this->distroInfo['service_manager'] = 'systemd';
        } elseif (file_exists('/sbin/initctl') && is_executable('/sbin/initctl')) {
            $this->distroInfo['service_manager'] = 'upstart';
        } else {
            $this->distroInfo['service_manager'] = 'sysvinit';
        }
    }

    /**
     * Get distribution ID
     */
    public function getId() {
        return $this->distroInfo['id'] ?? 'unknown';
    }

    /**
     * Get distribution name
     */
    public function getName() {
        return $this->distroInfo['name'] ?? 'Unknown Linux';
    }

    /**
     * Get distribution version
     */
    public function getVersion() {
        return $this->distroInfo['version'] ?? 'unknown';
    }

    /**
     * Get pretty name
     */
    public function getPrettyName() {
        return $this->distroInfo['pretty_name'] ?? $this->getName() . ' ' . $this->getVersion();
    }

    /**
     * Get package manager
     */
    public function getPackageManager() {
        return $this->distroInfo['package_manager'] ?? 'unknown';
    }

    /**
     * Get service manager
     */
    public function getServiceManager() {
        return $this->distroInfo['service_manager'] ?? 'systemd';
    }

    /**
     * Check if distribution is RHEL-based
     */
    public function isRhelBased() {
        $rhelIds = ['rhel', 'centos', 'almalinux', 'rocky', 'fedora', 'ol', 'oracle'];
        return in_array($this->getId(), $rhelIds) ||
               (isset($this->distroInfo['id_like']) && stripos($this->distroInfo['id_like'], 'rhel') !== false);
    }

    /**
     * Check if distribution is Debian-based
     */
    public function isDebianBased() {
        $debianIds = ['debian', 'ubuntu', 'mint', 'pop'];
        return in_array($this->getId(), $debianIds) ||
               (isset($this->distroInfo['id_like']) && stripos($this->distroInfo['id_like'], 'debian') !== false);
    }

    /**
     * Get Apache service name
     */
    public function getApacheServiceName() {
        return $this->isRhelBased() ? 'httpd' : 'apache2';
    }

    /**
     * Get Apache config path
     */
    public function getApacheConfigPath() {
        return $this->isRhelBased() ? '/etc/httpd' : '/etc/apache2';
    }

    /**
     * Get MySQL/MariaDB service name
     */
    public function getMySQLServiceName() {
        // Check which service exists
        $services = ['mariadb', 'mysql', 'mysqld'];
        foreach ($services as $service) {
            $check = shell_exec("systemctl list-unit-files | grep -E '^{$service}\\.service'");
            if (!empty($check)) {
                return $service;
            }
        }
        return 'mariadb'; // Default
    }

    /**
     * Get Asterisk config path
     */
    public function getAsteriskConfigPath() {
        return '/etc/asterisk'; // Standard across all distributions
    }

    /**
     * Get all distribution info
     */
    public function getInfo() {
        return $this->distroInfo;
    }

    /**
     * Check if distribution is supported
     */
    public function isSupported($supportedDistros = []) {
        if (empty($supportedDistros)) {
            // Default supported distributions
            $supportedDistros = [
                'rhel' => ['8', '9'],
                'almalinux' => ['8', '9'],
                'rocky' => ['8', '9'],
                'centos' => ['7', '8'],
                'ubuntu' => ['18.04', '20.04', '22.04', '24.04'],
                'debian' => ['10', '11', '12'],
                'fedora' => ['36', '37', '38', '39'],
            ];
        }

        $distroId = $this->getId();
        $version = $this->getVersion();

        if (!isset($supportedDistros[$distroId])) {
            return false;
        }

        // Check if version is in supported list
        foreach ($supportedDistros[$distroId] as $supportedVersion) {
            if (version_compare($version, $supportedVersion, '>=') &&
                version_compare($version, (float)$supportedVersion + 1, '<')) {
                return true;
            }
            // Also check for exact match (handles versions like "24.04")
            if ($version === $supportedVersion) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get installation command for package
     */
    public function getInstallCommand($package) {
        $pm = $this->getPackageManager();

        switch ($pm) {
            case 'dnf':
                return "dnf install -y {$package}";
            case 'yum':
                return "yum install -y {$package}";
            case 'apt':
            case 'apt-get':
                return "apt-get install -y {$package}";
            case 'zypper':
                return "zypper install -y {$package}";
            case 'pacman':
                return "pacman -S --noconfirm {$package}";
            default:
                return "# Unknown package manager, please install {$package} manually";
        }
    }
}
