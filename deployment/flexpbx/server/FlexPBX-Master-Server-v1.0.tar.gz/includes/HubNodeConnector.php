<?php
/**
 * FlexPBX HubNode Connector
 *
 * Integrates FlexPBX with HubNode API for:
 * - Centralized event logging
 * - Multi-tenant management
 * - Cross-platform authentication
 * - Resource sharing
 *
 * @version 1.0
 * @package FlexPBX
 */

class HubNodeConnector {
    private $config;
    private $baseUrl;
    private $apiEndpoint;
    private $apiKey;
    private $lastError = null;

    public function __construct($config = []) {
        $this->config = $config['hubnode'] ?? [];
        $this->baseUrl = rtrim($this->config['url'] ?? '', '/');
        $this->apiEndpoint = $this->config['api_endpoint'] ?? '/api/v1';
        $this->apiKey = $this->config['api_key'] ?? '';
    }

    /**
     * Check if HubNode integration is enabled
     */
    public function isEnabled() {
        return !empty($this->config['enabled']) && !empty($this->baseUrl);
    }

    /**
     * Register this FlexPBX installation with HubNode
     */
    public function registerInstallation($data) {
        if (!$this->isEnabled()) {
            return ['success' => false, 'error' => 'HubNode integration not enabled'];
        }

        $payload = [
            'installation_type' => 'flexpbx',
            'version' => $data['version'] ?? '1.0',
            'server_url' => $data['server_url'] ?? $_SERVER['HTTP_HOST'],
            'admin_email' => $data['admin_email'] ?? '',
            'features' => $data['features'] ?? [],
            'timestamp' => time(),
        ];

        $response = $this->makeRequest('POST', '/installations/register', $payload);

        if ($response['success']) {
            // Store installation ID for future requests
            $this->storeInstallationId($response['data']['installation_id'] ?? null);
        }

        return $response;
    }

    /**
     * Send event to HubNode
     */
    public function logEvent($eventType, $eventData, $severity = 'INFO') {
        if (!$this->isEnabled() || empty($this->config['features']['event_logging'])) {
            return ['success' => false, 'error' => 'Event logging not enabled'];
        }

        $payload = [
            'installation_id' => $this->getInstallationId(),
            'event_type' => $eventType,
            'event_data' => $eventData,
            'severity' => $severity,
            'timestamp' => time(),
            'source' => 'flexpbx',
        ];

        return $this->makeRequest('POST', $this->config['events_endpoint'] ?? '/events', $payload);
    }

    /**
     * Authenticate with HubNode
     */
    public function authenticate($credentials) {
        if (!$this->isEnabled()) {
            return ['success' => false, 'error' => 'HubNode integration not enabled'];
        }

        $payload = [
            'installation_id' => $this->getInstallationId(),
            'username' => $credentials['username'] ?? '',
            'password' => $credentials['password'] ?? '',
            'auth_type' => 'flexpbx',
        ];

        return $this->makeRequest('POST', $this->config['auth_endpoint'] ?? '/auth', $payload);
    }

    /**
     * Check HubNode connectivity
     */
    public function checkConnection() {
        if (!$this->isEnabled()) {
            return ['success' => false, 'error' => 'HubNode integration not enabled'];
        }

        $response = $this->makeRequest('GET', '/health');
        return [
            'success' => $response['success'] ?? false,
            'latency_ms' => $response['latency_ms'] ?? 0,
            'version' => $response['data']['version'] ?? 'unknown',
        ];
    }

    /**
     * Make HTTP request to HubNode API
     */
    private function makeRequest($method, $endpoint, $data = []) {
        $url = $this->baseUrl . $this->apiEndpoint . $endpoint;

        $ch = curl_init();
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: FlexPBX/1.0',
        ];

        if (!empty($this->apiKey)) {
            $headers[] = 'Authorization: Bearer ' . $this->apiKey;
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => $this->config['timeout'] ?? 30,
            CURLOPT_SSL_VERIFYPEER => $this->config['verify_ssl'] ?? true,
        ]);

        $startTime = microtime(true);

        if ($method === 'POST' || $method === 'PUT') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $latency = round((microtime(true) - $startTime) * 1000);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            $this->lastError = "cURL Error: " . $curlError;
            return [
                'success' => false,
                'error' => $this->lastError,
                'http_code' => $httpCode,
            ];
        }

        $decoded = json_decode($response, true);

        return [
            'success' => $httpCode >= 200 && $httpCode < 300,
            'http_code' => $httpCode,
            'data' => $decoded ?? [],
            'latency_ms' => $latency,
        ];
    }

    /**
     * Store installation ID in config
     */
    private function storeInstallationId($id) {
        if (empty($id)) return;

        $configFile = __DIR__ . '/hubnode_installation.json';
        $config = [
            'installation_id' => $id,
            'registered_at' => date('Y-m-d H:i:s'),
        ];
        file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
    }

    /**
     * Get stored installation ID
     */
    private function getInstallationId() {
        $configFile = __DIR__ . '/hubnode_installation.json';
        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true);
            return $config['installation_id'] ?? null;
        }
        return null;
    }

    /**
     * Get last error message
     */
    public function getLastError() {
        return $this->lastError;
    }
}
