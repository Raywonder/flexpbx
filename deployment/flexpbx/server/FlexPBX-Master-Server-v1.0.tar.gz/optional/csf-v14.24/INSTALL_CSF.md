# CSF (ConfigServer Security & Firewall) Installation

**Version:** 14.24 (cPanel Edition)
**Included with:** FlexPBX v1.0 Installer (Optional Component)

## What is CSF?

CSF (ConfigServer Security & Firewall) is a Stateful Packet Inspection (SPI) firewall, Login/Intrusion Detection and Security application for Linux servers.

**Features:**
- Advanced firewall configuration
- Login Failure Daemon (LFD) for brute force protection
- Port flooding detection
- Process tracking
- Directory watching
- Messenger service
- Cluster support
- cPanel/WHM integration
- Web UI for management

## When to Use CSF

✅ **Use CSF if:**
- Running cPanel/WHM server
- Need advanced firewall features
- Want integrated login protection
- Require cluster firewall management
- Familiar with CSF configuration

❌ **Don't use CSF if:**
- Using Ubuntu/Debian (use UFW + fail2ban instead)
- Server already has firewalld configured
- Minimal server requiring simple firewall
- Don't need cPanel integration

## Installation

### Prerequisites

```bash
# RHEL/CentOS/AlmaLinux/Rocky Linux
sudo dnf install -y perl-libwww-perl perl-LWP-Protocol-https \
    perl-GDGraph iptables iptables-services

# Ensure iptables-services is enabled (not firewalld)
sudo systemctl disable firewalld
sudo systemctl stop firewalld
sudo systemctl enable iptables
sudo systemctl enable ip6tables
```

### Install CSF

**Option 1: From this package (Recommended)**

```bash
# Navigate to CSF directory
cd /path/to/flexpbx-installer/optional/csf-v14.24/

# Copy executables
sudo cp csf lfd /usr/sbin/
sudo chmod 700 /usr/sbin/csf /usr/sbin/lfd

# Extract configuration
sudo tar -xzf csf-config.tar.gz -C /etc/

# Set permissions
sudo chown -R root:root /etc/csf
sudo chmod 600 /etc/csf/csf.conf

# Install Perl modules (if missing)
sudo perl -MCPAN -e 'install LWP::UserAgent'

# Start CSF
sudo csf -r

# Enable on boot
sudo systemctl enable csf
sudo systemctl enable lfd
```

**Option 2: Fresh download (if available)**

```bash
# Note: CSF website may no longer be available
# Use the packaged version above instead

# If downloading from alternative source:
cd /usr/src
wget https://download.configserver.com/csf.tgz
tar -xzf csf.tgz
cd csf
sudo sh install.sh
```

### Verify Installation

```bash
# Check CSF version
sudo csf -v

# Test CSF
sudo perl /usr/local/csf/bin/csftest.pl

# Check status
sudo csf -l

# Check LFD status
sudo systemctl status lfd
```

## FlexPBX Integration

### Required Ports for FlexPBX

The included `csf.conf.sample` already has these configured:

```bash
# HTTP/HTTPS
TCP_IN: 80,443
TCP_OUT: 80,443

# SIP (Asterisk)
TCP_IN: 5060,5061
TCP_OUT: 5060,5061
UDP_IN: 5060,5061
UDP_OUT: 5060,5061

# RTP (Voice/Video)
UDP_IN: 10000:20000
UDP_OUT: 10000:20000

# STUN/TURN
TCP_IN: 3478
TCP_OUT: 3478
UDP_IN: 3478,50000:65535
UDP_OUT: 3478,50000:65535

# SSH
TCP_IN: 22
TCP_OUT: 22

# MySQL/MariaDB (if remote)
TCP_IN: 3306
TCP_OUT: 3306
```

### Apply FlexPBX Configuration

```bash
# Backup current config
sudo cp /etc/csf/csf.conf /etc/csf/csf.conf.backup

# Copy FlexPBX-optimized config
sudo cp csf.conf.sample /etc/csf/csf.conf

# Restart CSF
sudo csf -r
```

## Configuration

### Basic Configuration

Edit `/etc/csf/csf.conf`:

```bash
sudo nano /etc/csf/csf.conf
```

**Important settings:**

```ini
# Set to production mode (disable testing)
TESTING = "0"

# Allow ICMP ping
ICMP_IN = "1"

# Login Failure Daemon
LF_DAEMON = "1"
LF_TRIGGER = "3"      # Block after 3 failed logins
LF_TRIGGER_PERM = "1" # Permanent block after repeated failures

# Port Knocking (optional)
PORTKNOCKING = "0"

# Cluster (if multiple servers)
CLUSTER_SENDTO = ""
CLUSTER_RECVFROM = ""

# Messenger Service
MESSENGER = "1"
MESSENGER_HTML = "1"

# Webmin/WHM UI
UI = "1"
UI_PORT = "6666"
```

### Whitelist IPs

```bash
# Add trusted IPs to allowlist
echo "YOUR_IP_ADDRESS # My Office" | sudo tee -a /etc/csf/csf.allow

# Reload CSF
sudo csf -r
```

### Block an IP

```bash
# Temporary block
sudo csf -d 1.2.3.4

# Permanent block
sudo csf -d 1.2.3.4
echo "1.2.3.4 # Blocked reason" | sudo tee -a /etc/csf/csf.deny
```

## CSF Commands

```bash
# Start CSF
sudo csf -s

# Stop CSF
sudo csf -f

# Restart CSF
sudo csf -r

# Reload CSF
sudo csf -ra

# List rules
sudo csf -l

# Check logs
sudo csf -g 1.2.3.4

# Allow an IP
sudo csf -a 1.2.3.4 "Reason"

# Deny an IP
sudo csf -d 1.2.3.4 "Reason"

# Remove allow/deny
sudo csf -ar 1.2.3.4
sudo csf -dr 1.2.3.4

# Unblock all temporary blocks
sudo csf -tf

# Test CSF
sudo perl /usr/local/csf/bin/csftest.pl
```

## Web UI Access

If UI is enabled in csf.conf:

1. Access: `https://your-server-ip:6666/`
2. Login with root credentials
3. Manage firewall through web interface

**Security:** Change default port 6666 in csf.conf for added security.

## LFD (Login Failure Daemon)

LFD monitors logs for failed login attempts and automatically blocks IPs.

### Check LFD Status

```bash
sudo systemctl status lfd
```

### LFD Logs

```bash
sudo tail -f /var/log/lfd.log
```

### Manually Trigger LFD

```bash
sudo /usr/sbin/lfd
```

## Integration with fail2ban

CSF and fail2ban can work together, but coordinate to avoid conflicts:

**Option 1: Use CSF only (Recommended for cPanel)**
```bash
sudo systemctl stop fail2ban
sudo systemctl disable fail2ban
```

**Option 2: Use both (Advanced)**
- Configure fail2ban to use csf banaction
- Edit `/etc/fail2ban/jail.local`:
```ini
[DEFAULT]
banaction = csf-ip-deny
```

## Troubleshooting

### CSF Not Starting

```bash
# Check for errors
sudo csf -v

# Verify iptables
sudo iptables -L -n

# Check if firewalld is running (conflicts with CSF)
sudo systemctl status firewalld
```

### Port Not Opening

```bash
# Verify port in config
sudo grep "TCP_IN\|UDP_IN" /etc/csf/csf.conf

# Check if port is blocked
sudo csf -g 5060

# Restart CSF
sudo csf -r
```

### IP Not Blocked

```bash
# Check if IP is in deny list
sudo grep "1.2.3.4" /etc/csf/csf.deny

# Manually verify iptables
sudo iptables -L -n | grep 1.2.3.4

# Check LFD logs
sudo tail -100 /var/log/lfd.log | grep 1.2.3.4
```

### Performance Issues

```bash
# Reduce logging
# Edit /etc/csf/csf.conf
LF_INTERVAL = "3600"     # Check every hour instead of constantly
PT_LIMIT = "60"          # Reduce process tracking
PS_INTERVAL = "300"      # Less frequent port scans

# Restart
sudo csf -r
```

## Uninstallation

If you need to remove CSF:

```bash
# Stop services
sudo csf -x
sudo systemctl stop lfd

# Remove CSF
cd /etc/csf
sudo sh uninstall.sh

# Or manually:
sudo rm -rf /etc/csf
sudo rm -f /usr/sbin/csf /usr/sbin/lfd
sudo rm -f /etc/systemd/system/csf.service
sudo rm -f /etc/systemd/system/lfd.service

# Re-enable firewalld if needed
sudo systemctl enable firewalld
sudo systemctl start firewalld
```

## Best Practices

1. **Always whitelist your IP** before enabling CSF to avoid lockout
2. **Test in TESTING mode** first (TESTING = "1")
3. **Monitor logs** regularly: `/var/log/lfd.log`
4. **Keep CSF updated** (though updates may be limited now)
5. **Backup configuration** before major changes
6. **Document all custom rules**
7. **Use cluster mode** for multiple servers
8. **Enable UI** only if needed (security risk)

## Security Considerations

- CSF runs as root - ensure proper permissions
- Web UI is a potential attack vector - change default port
- Whitelist management IPs before deployment
- Regular log review for suspicious activity
- Coordinate with fail2ban to avoid conflicts
- Test firewall rules before production deployment

## Support and Resources

Since CSF's official website may be unavailable:

- **Documentation:** Included in /etc/csf/readme.txt
- **Community:** cPanel forums, WebHostingTalk
- **Alternative:** Consider firewalld + fail2ban for modern systems

## Included Files

This package includes:

- `csf` - Main firewall binary (246KB)
- `lfd` - Login Failure Daemon binary (383KB)
- `csf-config.tar.gz` - Complete /etc/csf configuration (533KB)
- `csf.conf.sample` - FlexPBX-optimized configuration
- This installation guide

**Total Package Size:** ~1.2MB

**Version:** CSF v14.24 (cPanel Edition)
**Packaged:** 2025-10-18
**Compatible:** RHEL 8+, CentOS 8+, AlmaLinux 8+, Rocky Linux 8+, Fedora 38+

---

*This is a preserved copy of CSF v14.24 included with FlexPBX for compatibility with cPanel servers. For non-cPanel systems, we recommend using UFW (Ubuntu/Debian) or firewalld (RHEL/Fedora) with fail2ban.*
